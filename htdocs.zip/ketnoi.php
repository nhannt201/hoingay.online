
<?php
     $db_con = mysql_connect("localhost","root","");
mysql_set_charset('utf8');

     if (!$db_con){
          die('Không thể kết nối database: ' . mysql_error());
     }
     mysql_select_db("hoidap", $db_con);
	 	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hoidap";
$dbhost = 'localhost';
            $dbuser = 'root';
            $dbpass = '';
?>

