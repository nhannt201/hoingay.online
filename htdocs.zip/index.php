<?php
//Khai báo sử dụng session
session_start();

if (file_exists("laivt_firewall.php"))
     include_once "laivt_firewall.php";  
?>
<?php
$hiden = "";
?>
<html lang="vi">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<link rel="icon" type="image/png" href="/images/ico.ico"/>
    <title>Hỏi Đáp Có Ngay - Lưu Trữ 360</title>
    <meta name="title" content="Hỏi Đáp Có Ngay"/>
    <meta name="KEYWORDS" content="FAQ Online, hoi dap, truc tuyn , hoi dap online,luutru360, hoi ngay co dap">
    <meta name="DESCRIPTION" content="Hỏi Đáp Có Ngay - Hỏi đáp có ngay trao đổi kiến thức qua câu hỏi và câu trả lời trong 24h.">

    <meta http-equiv="EXPIRES" content="0"/>
    <meta name="RESOURCE-TYPE" content="DOCUMENT"/>
    <meta name="DISTRIBUTION" content="GLOBAL"/>
    <meta name="AUTHOR" content="Hỏi Đáp Có Ngay - Hỏi đáp có ngay trao đổi kiến thức qua câu hỏi và câu trả lời trong 24h"/>
    <meta name="COPYRIGHT" content="Copyright (c) by luturu360.com"/>
            <meta name="ROBOTS" content="INDEX, FOLLOW"/>
        <meta name="Googlebot" content="index,follow,archive">
        <meta name="RATING" content="GENERAL"/>
    <meta name="GENERATOR" content="luutru360.com"/>
    <meta name="geo.region" content="Vietnam"/>

    <meta name="og:title" content="Hỏi Đáp Có Ngay - Hỏi ngay có đáp"/>
    <meta name="og:description" content="Hỏi Đáp Có Ngay - Hỏi đáp có ngay trao đổi kiến thức qua câu hỏi và câu trả lời trong 24h."/>
    <meta name="og:url" content="http://luutru360.com"/>
    <meta name="og:image" content="http://luutru360.com/images/logo.png"/>
    <meta property="og:image:type" content="image/png" />
    <link rel="shortcut icon" href="/images/ico.ico"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style type='text/css'>
		body{
		padding-top: 20px;
		padding-bottom: 50px;
		margin: 0px;
		}
	</style>
	<link rel='stylesheet' type='text/css' href='css/theme.css' />
    <link rel='stylesheet' type='text/css' href='css/data.css' />


<!--
tbody tr:hover{
    background: #B8C6D7;
}
-->

    </head>
	 <body data-base="http://luutru360.com/">
	<div class="floating-menu"><center><h1>Hỏi Đáp Có Ngay - Lưu Trữ 360</h1>
	</center>
	
	</div>
	<center><h1>Hỏi Đáp Có Ngay - Lưu Trữ 360</h1></center>
		<h3><?php
       if (isset($_SESSION['username']) && $_SESSION['username']){
          echo 'Chào, '.$_SESSION['username'].' .Chúc bạn ngày tốt lành!';
       }
       else{

       }
       ?></h3>
	   <TABLE  BORDER="1"><td>
	 <center>  <a href="quangcao/quangcaoview.php"><img src="http://static.taiiwin.net/event/iwin.gif" width="550" height="”200”"></a></center></td>
	 </TABLE>
	<div id="menu">
	<ul>
<li class="current_page_item"><a href="/" accesskey="1" title="Trang chủ">Trang chủ</a></li><br/>
 

  <?php
       if (isset($_SESSION['username']) && $_SESSION['username']){
          echo '<li><a href="thoat">Đăng xuất</a></li>';
       }
       else{
echo "<li><a href='/dang-ky-tai-khoan' accesskey='2' title='Đăng ký'>Đăng Ký</a></li><br/>
<li><a href='/dang-nhap' accesskey='3' title='Đăng nhập'>Đăng Nhập</a></li><br/>";
       }
       ?>
</ul>
	</div>
	
		
	
<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>20 câu hỏi mới nhất</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT id from data ORDER BY id DESC LIMIT 20") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['id']);

 $sql = "select * from data where id = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD> <font color ='009900'><b>Câu Hỏi: </b></font><h4><b><a href='/view?id=".$data['id']."'>".$data['cauhoi']."</a></h4></b></TD></TR>"; 


}


?>
 <?php
       if (isset($_SESSION['username']) && $_SESSION['username']){
echo "<TR><TD><h2>  <a href='/add' />Tạo Chủ đề mới</a></h2></TR></TD>";
       }
       else{

       }
       ?>

</TABLE>

<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>10 Thành viên mới</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT id from member ORDER BY id DESC LIMIT 10") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['id']);

 $sql = "select * from member where id = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD><h4><a href='/user?id=".$data['id']."&u=".$data['username']."'>".$data['fullname']."</h4></th><th><center><a href='/user?id=".$data['id']."&u=".$data['username']."'>".$data['username']."</h4></th></center></a></TD></TR>"; 


}


?>

</TABLE>

<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>Top 10 thành viên có nhiều bài viết</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT view from vieww ORDER BY view DESC LIMIT 10") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['view']);

 $sql = "select * from vieww where view = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD><font color='red'><h4>".$data['idd']."</h4></font></th><th><h3>Số bài viết: ".$data['view']."</h3></th</TD></TR>"; 


}


?>

</TABLE>

<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>Top 10 thành viên có nhiều bình luận</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT view from topcmm ORDER BY view DESC LIMIT 10") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['view']);

 $sql = "select * from topcmm where view = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD><font color='00CC66'><h4>".$data['user']."</font></h4></th><th><h3>Số bình luận: ".$data['view']."</h3></th</TD></TR>"; 


}


?>

</TABLE>

<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>Top 10 thành viên có nhiều chủ đề</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT view from chudee ORDER BY view DESC LIMIT 10") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['view']);

 $sql = "select * from chudee where view = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD><font color='999900'><h4>".$data['user']."</h4></font></th><th><h3>Số chủ đề: ".$data['view']."</h3></th</TD></TR>"; 


}


?>

</TABLE>

<TABLE  BORDER="1">

<?php


	echo "<TR><TD COLSPAN='2'>

<h2>Top 10 thành viên có điểm nhiều nhất</h2></TD></TR>";
include("ketnoi.php");
$kq=mysql_query("SELECT diem from diemso ORDER BY diem DESC LIMIT 10") or die ("Không thể xuất thông tin Bảng tb ".mysql_error());
while ($row=mysql_fetch_array($kq)) 
{ 

$id2 = mysql_real_escape_string($row['diem']);

 $sql = "select * from diemso where diem = $id2";
  $result = mysql_query($sql);
  $data = mysql_fetch_array ($result);
  echo "<TR><TD><font color='003366'><h4>".$data['user']."</font></h4></th><th><h3>Điểm số: ".$data['diem']."</h3></th</TD></TR>"; 


}


?>

</TABLE>
<script id="_wau9i6">var _wau = _wau || []; _wau.push(["small", "guo5aqbfcomf", "9i6"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/small.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>




   <div class="lt36-footer-copyright">
        	<div class="body">
            	<div class="logof for-home-destop">
				<a href="/"><img src="/images/logo.png"  width="350" alt="logo"/></a>
											
				</div>
               	<div class="menuu"><center><h1>Hỏi Đáp Có Ngay</h1><br/><h3>Bản quyền thuộc về Luutru360.com Copyright (C) 2015</h3><br/><table id="footer" style="text-align: right;"><TR><TD><h4>Trang này mở ra nhằm mục đích trao đổi  kiến thức cho cộng đồng và xã hội ,
				<br/>những câu hỏi và bài viết có ý thô tục sẽ bị xoá mà không báo trước.</h4></TD></TR></TABLE></center></div>
				</div>

	 </body>
	 </html>
	 <!-- Copyright (C) Dien dan chia se kien thuc Luutru360.com - Luu tru 360 2015 -->

