  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php session_start();
 
if (isset($_SESSION['username'])){
    unset($_SESSION['username']); // xóa session email
}
 echo "<meta http-equiv='refresh' content='0;/'>";
?>
